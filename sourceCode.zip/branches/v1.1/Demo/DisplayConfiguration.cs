using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Demo
{
    public partial class DisplayConfiguration
    {
    }
}
