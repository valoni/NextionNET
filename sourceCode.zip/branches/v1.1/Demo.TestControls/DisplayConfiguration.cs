namespace Demo.TestControls
{
    public partial class DisplayConfiguration
    {
        public enum MyPictures
        {
            Smyle1 = Pictures.Picture0_21096813,
            Smyle2 = Pictures.Picture1_6E24BC27,
            Smyle3 = Pictures.Picture2_1B323EDF,
        }
    }
}
