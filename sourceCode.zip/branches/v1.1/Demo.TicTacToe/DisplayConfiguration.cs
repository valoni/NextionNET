using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Demo.TicTacToe
{
    public partial class DisplayConfiguration
    {
        public enum MyPictures
        {
            Board = Pictures.Picture0_7DFE762F,
            O = Pictures.Picture1_DA2890A1,
            X = Pictures.Picture2_DD0DD832,
            O_Small = Pictures.Picture3_75422A29,
            X_Small = Pictures.Picture4_502BC85E,
            Empty = Pictures.Picture5_9ABA8B22
        }

        public partial class Page1
        {
            public static Driver.Controls.PictureBox[] PlayGround;
            static partial void UserInit(NextionNET.Driver.NextionDisplay display)
            {
                PlayGround = new[] { PlayGround00, PlayGround01, PlayGround02, PlayGround10, PlayGround11, PlayGround12, PlayGround20, PlayGround21, PlayGround22 };
            }
        }
    }
}
