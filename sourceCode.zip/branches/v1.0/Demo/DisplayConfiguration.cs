using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Demo
{
    class DisplayConfiguration
    {
        public enum Fonts
        {
            Sanserif_16,
            Sanserif_16_Bold,
            Sanserif_40,
        }

        public enum Pictures
        {
        }

        public class Page0
        {
            public const byte Id = 0;

            public static Driver.Controls.ProgressBar ProgressBar;

            public static void Init(Driver.NextionDisplay display)
            {
                //Just a placeholder. In this case we dont use touch event on controls, so we dont need dummy one
                display.Controls.DefineDummy(Id);
                display.Controls.DefineDummy(Id);
                ProgressBar = display.Controls.DefineProgressBar(Id, "p0");
            }
        }

        public class Page1
        {
            public const string Name = "ready";
            public const byte Id = 1;

            public static void Init(Driver.NextionDisplay display)
            {
                //Nothing usefull there. Can skip
            }
        }

        public class Page2
        {
            public const byte Id = 2;

            public static Driver.Controls.TextBox MainTextbox;
            public static Driver.Controls.Button ButtonTime;
            public static Driver.Controls.Button ButtonDate;
            public static Driver.Controls.Button ButtonSleep;
            public static Driver.Controls.Button ButtonDraw5;

            public static void Init(Driver.NextionDisplay display)
            {
                MainTextbox = display.Controls.DefineTextBox(Id, "t0");
                ButtonTime = display.Controls.DefineButton(Id, "b0");
                ButtonDate = display.Controls.DefineButton(Id, "b1");
                ButtonSleep = display.Controls.DefineButton(Id, "b2");
                ButtonDraw5 = display.Controls.DefineButton(Id, "b3");
            }
        }

        public class Page3
        {
            public const byte Id = 3;

            public static Driver.Controls.TextBox X, Y;

            public static void Init(Driver.NextionDisplay display)
            {
                display.Controls.DefineDummy(Id);
                X = display.Controls.DefineTextBox(Id, "t1");
                Y = display.Controls.DefineTextBox(Id, "t2");
            }
        }

        public static void Init(Driver.NextionDisplay display)
        {
            Page0.Init(display);
            Page1.Init(display);
            Page2.Init(display);
            Page3.Init(display);
        }
    }
}
