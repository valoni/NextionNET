using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Demo.TicTacToe
{
    public enum GameState
    {
        Score,
        Game
    }
}
