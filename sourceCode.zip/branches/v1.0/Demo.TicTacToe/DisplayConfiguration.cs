using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Demo.TicTacToe
{
    public static class DisplayConfiguration
    {
        public enum Fonts
        {
            Sanserif_16,
            Sanserif_40,
            Sanserif_40_Bold,
            Sanserif_24,
        }

        public enum Pictures
        {
            Board,
            O,
            X,
            O_Small,
            X_Small,
            Empty
        }

        public class Page0
        {
            public const byte Id = 0;

            public static Driver.Controls.TextBox Score_X;
            public static Driver.Controls.TextBox Score_O;

            public static void Init(Driver.NextionDisplay display)
            {
                //Just a placeholder. In this case we dont use touch event on controls, so we dont need dummy one
                display.Controls.DefineDummy(Id);
                display.Controls.DefineDummy(Id);
                display.Controls.DefineDummy(Id);
                //ID:4
                Score_X = display.Controls.DefineTextBox(Id, "t2");
                display.Controls.DefineDummy(Id);
                display.Controls.DefineDummy(Id);
                //ID:7
                Score_O = display.Controls.DefineTextBox(Id, "t4");
            }
        }

        public class Page1
        {
            public const byte Id = 1;

            public static Driver.Controls.PictureBox NextMove;

            public static Driver.Controls.PictureBox PlayGround00;
            public static Driver.Controls.PictureBox PlayGround01;
            public static Driver.Controls.PictureBox PlayGround02;

            public static Driver.Controls.PictureBox PlayGround10;
            public static Driver.Controls.PictureBox PlayGround11;
            public static Driver.Controls.PictureBox PlayGround12;

            public static Driver.Controls.PictureBox PlayGround20;
            public static Driver.Controls.PictureBox PlayGround21;
            public static Driver.Controls.PictureBox PlayGround22;

            public static Driver.Controls.PictureBox[] PlayGround;

            public static void Init(Driver.NextionDisplay display)
            {
                //Just a placeholder. In this case we dont use touch event on controls, so we dont need dummy one
                display.Controls.DefineDummy(Id);
                display.Controls.DefineDummy(Id);
                //ID:3
                NextMove = display.Controls.DefinePictureBox(Id, "p1");
                //ID:4
                PlayGround00 = display.Controls.DefinePictureBox(Id, "p2");
                PlayGround01 = display.Controls.DefinePictureBox(Id, "p3");
                PlayGround02 = display.Controls.DefinePictureBox(Id, "p4");
                //ID:7
                PlayGround10 = display.Controls.DefinePictureBox(Id, "p5");
                PlayGround11 = display.Controls.DefinePictureBox(Id, "p6");
                PlayGround12 = display.Controls.DefinePictureBox(Id, "p7");
                //ID:10
                PlayGround20 = display.Controls.DefinePictureBox(Id, "p8");
                PlayGround21 = display.Controls.DefinePictureBox(Id, "p9");
                PlayGround22 = display.Controls.DefinePictureBox(Id, "p10");

                PlayGround = new[] { PlayGround00, PlayGround01, PlayGround02, PlayGround10, PlayGround11, PlayGround12, PlayGround20, PlayGround21, PlayGround22 };
            }
        }

        public static void Init(Driver.NextionDisplay display)
        {
            Page0.Init(display);
            Page1.Init(display);
        }
    }
}
