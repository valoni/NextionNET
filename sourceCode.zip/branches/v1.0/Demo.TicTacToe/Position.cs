using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Demo.TicTacToe
{
    public enum Position : byte
    {
        Empty,
        X,
        O
    }
}
