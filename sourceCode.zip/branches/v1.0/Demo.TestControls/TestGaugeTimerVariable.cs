using System;
using Microsoft.SPOT;
using JernejK.NextionNET.Driver;
using System.Threading;

namespace Demo.TestControls
{
    class TestGaugeTimerVariable
    {
        public static void Test(NextionDisplay display)
        {
            display.PageId = DisplayConfiguration.Page3.Id;
            display.TouchMode = TouchMode.Component;

            int[] pointerColors = { (int)Color.Black, (int)Color.Green, (int)Color.Red, (int)Color.Yellow, (int)Color.Blue };
            byte nextColorIndex = 0;

            display.TouchEvent += (sender, args) =>
                {
                    var ctrl = args.ResolveControl();
                    if (ctrl == null)
                        return;

                    if (ctrl == DisplayConfiguration.Page3.SpeedFast)
                    {
                        //Fast timer
                        DisplayConfiguration.Page3.Timer1.Timeout = 100;
                    }
                    else if (ctrl == DisplayConfiguration.Page3.SpeedSlow)
                    {
                        DisplayConfiguration.Page3.Timer1.Timeout = 400;
                    }
                    else if (ctrl == DisplayConfiguration.Page3.PointerColor)
                    {
                        //Reading or writing to Nextion display require new thread.
                        ThreadHelper.Run(() =>
                            {
                                DisplayConfiguration.Page3.Gauge.ForegroundColor = pointerColors[nextColorIndex];
                                DisplayConfiguration.Page3.Gauge.Refresh();
                                nextColorIndex++;
                                if (nextColorIndex >= pointerColors.Length)
                                    nextColorIndex = 0;
                            });
                    }
                    else if (ctrl == DisplayConfiguration.Page3.PointerThickness)
                    {
                        //Reading or writing to Nextion display require new thread.
                        ThreadHelper.Run(() =>
                            {
                                byte tickness = DisplayConfiguration.Page3.Gauge.Thickness;
                                tickness++;
                                if (tickness >= 5)
                                    tickness = 1;

                                DisplayConfiguration.Page3.Gauge.Thickness = tickness;
                                DisplayConfiguration.Page3.Gauge.Refresh();
                            });
                    }
                    else if (ctrl == DisplayConfiguration.Page3.Start)
                    {
                        DisplayConfiguration.Page3.Variable1.Val = 0;
                        DisplayConfiguration.Page3.Timer1.Enabled = true;
                    }
                };

            Thread.Sleep(Timeout.Infinite);
        }
    }
}
