using System;
using Microsoft.SPOT;
using JernejK.NextionNET.Driver;
using JernejK.NextionNET.Driver.Controls;
using JernejK.NextionNET.Driver.Controls.Hidden;

namespace Demo.TestControls
{
    public class DisplayConfiguration
    {
        public enum Fonts
        {
            Sanserif_16,
            Sanserif_16_Bold,
        }

        public enum Pictures
        {
            Smyle1,
            Smyle2,
            Smyle3,
        }

        public class Page0
        {
            public const byte Id = 0;

            public static TextBox T0;
            public static Button B0;
            public static ProgressBar J0;
            public static PictureBox P0;
            public static Slider H0;
            public static NumberBox N0;

            public static void Init(NextionDisplay display)
            {
                T0 = display.Controls.DefineTextBox(Id, "t0");
                B0 = display.Controls.DefineButton(Id, "b0");
                J0 = display.Controls.DefineProgressBar(Id, "j0");
                P0 = display.Controls.DefinePictureBox(Id, "p0");
                H0 = display.Controls.DefineSlider(Id, "h0");
                N0 = display.Controls.DefineNumberBox(Id, "n0");
            }
        }

        public class Page1
        {
            public const byte Id = 1;

            public static Waveform Wave;

            public static void Init(NextionDisplay display)
            {
                //In case you have waveform or touch event definition order is very important!
                Wave = display.Controls.DefineWaveform(Id, "s0");
            }
        }

        public class Page2
        {
            public const byte Id = 2;

            public static DualStateButton DualState;
            public static Button TestButton;
            public static TextBox ClickCounter;
            public static Button ContinueButton;

            public static void Init(NextionDisplay display)
            {
                DualState = display.Controls.DefineDualState(Id, "bt0");
                display.Controls.DefineDummy(Id);
                TestButton = display.Controls.DefineButton(Id, "b0");
                ClickCounter = display.Controls.DefineTextBox(Id, "t1");
                ContinueButton = display.Controls.DefineButton(Id, "b1");
            }
        }

        public class Page3
        {
            public const byte Id = 3;

            public static Gauge Gauge;
            public static Button SpeedSlow, SpeedFast, PointerColor, PointerThickness, Start;
            public static Timer Timer1;
            public static Variable Variable1;
            
            public static void Init(NextionDisplay display)
            {
                Gauge = display.Controls.DefineGauge(Id, "z0");
                Variable1 = display.Controls.DefineVariable(Id, "va0");
                Timer1 = display.Controls.DefineTimer(Id, "tm0");
                display.Controls.DefineDummy(Id);
                SpeedSlow = display.Controls.DefineButton(Id, "b0");
                SpeedFast = display.Controls.DefineButton(Id, "b1");
                PointerColor = display.Controls.DefineButton(Id, "b2");
                PointerThickness = display.Controls.DefineButton(Id, "b3");
                Start = display.Controls.DefineButton(Id, "b4");
            }
        }
        
        public static void Init(NextionDisplay display)
        {
            Page0.Init(display);
            Page1.Init(display);
            Page2.Init(display);
            Page3.Init(display);
        } 
    }
}
