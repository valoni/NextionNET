using System;
using Microsoft.SPOT;
using JernejK.NextionNET.Driver;
using System.Threading;

namespace Demo.TestControls
{
    class TestDualStateButtonAndDisableTouch
    {
        public static void Test(NextionDisplay display)
        {
            display.PageId = DisplayConfiguration.Page2.Id;
            DisplayConfiguration.Page2.TestButton.ChangeTouchEnabled(false);

            DisplayConfiguration.Page2.DualState.State = true;
            Debug.Print(DisplayConfiguration.Page2.DualState.State.ToString());
            DisplayConfiguration.Page2.DualState.State = false;
            Debug.Print(DisplayConfiguration.Page2.DualState.State.ToString());

            display.TouchMode = TouchMode.Component;
            var wait = new ManualResetEvent(false);
            int counter = 0;

            display.TouchEvent += (sender, args) =>
                {
                    var ctrl = args.ResolveControl();
                    if (ctrl == null)
                        return;

                    if (ctrl == DisplayConfiguration.Page2.ContinueButton)
                    {
                        wait.Set();
                    }
                    else if (ctrl == DisplayConfiguration.Page2.DualState)
                    {
                        ThreadHelper.Run(() =>
                            {
                                //Display dont provide new value in event so we need to read it
                                bool state = DisplayConfiguration.Page2.DualState.State;
                                Debug.Print("Dual state changed. New state: " + state);
                                DisplayConfiguration.Page2.TestButton.ChangeTouchEnabled(state);
                            });
                    }
                    else if (ctrl == DisplayConfiguration.Page2.TestButton)
                    {
                        DisplayConfiguration.Page2.ClickCounter.Text = (++counter).ToString();
                    }
                };

            wait.WaitOne();
        }

        static void display_TouchEvent(object sender, TouchEventArgs args)
        {
            throw new NotImplementedException();
        }
    }
}
