using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Driver
{
    public enum HorizontalAlignment
    {
        Left = 0,
        Center = 1,
        Right = 2,
    }
}
