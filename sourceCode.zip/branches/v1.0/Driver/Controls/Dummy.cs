using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Driver.Controls
{
    /// <summary>
    /// Placeholder for unused and unsupported methods
    /// </summary>
    public class DummyControl : Bases.ControlBase
    {
        internal DummyControl(byte pageId) : base(null, pageId, null)
        {
        }
    }

}
