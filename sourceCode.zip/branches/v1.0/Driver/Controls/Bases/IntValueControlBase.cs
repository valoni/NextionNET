using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Driver.Controls.Bases
{
    public abstract class IntValueControlBase : ForeBackColorSurfaceControlBase
    {
        public IntValueControlBase(NextionDisplay display, byte pageId, string id) : base(display, pageId, id)
        {

        }

        /// <summary>
        /// Value
        /// </summary>
        public int Val
        {
            get { return Display.GetAttributeValueInt(Id, "val"); }
            set { Display.SetAttributeValue(Id, "val", value); }
        }
    }
}
