using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Driver.Controls
{
    public class Button : Bases.TextControlTextBase
    {
        public Button(NextionDisplay display, byte pageId, string id) : base(display, pageId, id)
        {
        }
    }
}
