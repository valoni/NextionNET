using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Driver
{
    public class SystemEventParameter
    {
    }
}
