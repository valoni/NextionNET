using System;
using Microsoft.SPOT;

namespace JernejK.NextionNET.Driver
{
    public enum VerticalAlignment : byte
    {
        Top = 0,
        Center = 1,
        Bottom = 2,
    }
}
