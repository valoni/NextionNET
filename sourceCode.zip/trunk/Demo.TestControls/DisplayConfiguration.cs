namespace Demo.TestControls
{
    public partial class DisplayConfiguration
    {
        public enum MyPictures
        {
            Smyle1 = Pictures.Picture0_4C5C9ED1,
            Smyle2 = Pictures.Picture1_66B4FE23,
            Smyle3 = Pictures.Picture2_D735FB57,
        }
    }
}
